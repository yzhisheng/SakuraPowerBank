package com.share.auth.form;

/**
 * 用户注册对象
 *
 * @author share
 */
public class RegisterBody extends LoginBody
{

}
