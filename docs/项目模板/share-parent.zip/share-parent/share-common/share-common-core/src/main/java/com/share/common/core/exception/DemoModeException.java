package com.share.common.core.exception;

/**
 * 演示模式异常
 *
 * @author share
 */
public class DemoModeException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    public DemoModeException()
    {
    }
}
