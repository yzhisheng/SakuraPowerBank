package com.share.common.core.exception;

/**
 * 权限异常
 *
 * @author share
 */
public class PreAuthorizeException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    public PreAuthorizeException()
    {
    }
}
